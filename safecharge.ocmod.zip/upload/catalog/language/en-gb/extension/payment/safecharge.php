<?php
// Text
$_['rest_no_apms_error']        = '<strong>Error</strong> when try to get AMPs, please reload the page or start to Step 2!';
$_['sc_attention']              = 'Attention!';
$_['sc_go_to_step_2_error']     = 'You must confirm all steps starting from Step 2, to get correct APMs!';
$_['sc_upos_title']             = 'Choose from you prefered payment methods';
$_['sc_pms_title']              = 'Choose a payment method';
$_['choose_pm_error']           = 'Please, choose payment method and fill all its fields!';
$_['sc_token_error_2']          = 'Error when try to proceed the payment. Please, check you fields!';
$_['pm_error']                  = 'Payment method error, please choose another one and try again!';
$_['sc_order_declined']         = 'Your Payment was DECLINED. Please try another payment method!';
$_['sc_order_error']			= 'Error with your Payment. Please try again later!';

// change order status
$_['Payment_status_changed_to'] = 'Payment status changed to';